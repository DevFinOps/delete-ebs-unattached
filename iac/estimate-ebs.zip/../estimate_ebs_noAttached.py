import os
from time import sleep
from logging import basicConfig, info, error, INFO

#Variaveis de ambiente passadas através do AWS Lambda
BUCKET_NAME = os.environ.get("TARGET_BUCKET_S3")

#Criando um logging para o código
basicConfig(level=INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def get_data_csv_report_file():
  pass

# funcao lambda principal
def handler(event, context):
  try:
    info("Iniciando o processo de estimativa de EBS sem volumes anexados.")
    sleep(2)
    info("Concluido com sucesso!")
    return {
            'statusCode': 200,
            'body': "Sucesso"
        }

  except Exception as e:
    error(f"Erro capturado {e}")
    return {
            'statusCode': 500,
            'body': f'Erro capturado: {e}'
        }
        